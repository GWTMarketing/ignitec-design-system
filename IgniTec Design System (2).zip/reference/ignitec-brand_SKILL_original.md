---
name: ignitec-brand
description: "Definiert das Corporate Design und die Markenregeln der IGNITEC GmbH (Lichtenwörth, AT) — einem Generalvertrieb für kondensierte Aerosol-Löschgeneratoren. Verwende diesen Skill IMMER, wenn der User Inhalte, Dokumente, Websites, Grafiken, Präsentationen, Social Posts, Mails, Datenblätter, Etiketten oder Werbematerial für IgniTec erstellen oder in IgniTec-CI überführen will. Trigger bei: 'IgniTec', 'Ignitec', 'Aerosol-Generator', 'Brandunterdrückung', 'erstelle ... für Ignitec', 'bringe das in Ignitec-CI', 'Brandschutz-Content', 'Reaction. Protection. Solution.', oder wenn die Farben Kupfer/Slateblue, die Schriftarten Archivo/IBM Plex Sans, oder das Logo mit dem 'n' im Quadrat referenziert werden. Auch triggern bei generischen Requests wie 'Website für meine Brandschutz-Firma' wenn aus dem Kontext hervorgeht, dass IgniTec gemeint ist. NICHT verwenden für andere Brandschutz-Unternehmen oder allgemeine Design-Aufgaben ohne IgniTec-Bezug."
---

# IgniTec · Brand Design System

Corporate-Design- und Markenreferenz für die **IGNITEC GmbH**, Michael-Hainisch-Straße 8, A-2493 Lichtenwörth. Generalvertrieb kondensierter Aerosol-Löschgeneratoren in Österreich. Brand Strategy Rev. 3.0, April 2026.

**Kontakt:** office@ignitec.at · www.ignitec.at · FN 651979v · ATU81975427

---

## 1. Markenkern

| Element | Wert |
|---|---|
| **Claim** | Reaction. Protection. Solution. |
| **Markenidee** | Wir verkaufen nicht Löschmittel — wir verkaufen die Minute, in der nichts passiert. |
| **Tonalität** | technisch-präzise · ruhig · fallbezogen · partnerschaftlich |
| **Positionierung** | Der Generalvertrieb, der Aerosol-Technologie aus der Nische in den seriösen Objektschutz hebt. |
| **Hauptzielmarkt** | Österreich (DACH sekundär) |
| **Zielgruppen B2B** | Partner/Installateure · Planer/Sachverständige · Endkunden (KMU, Facility, BESS-Betreiber) |

Den Claim immer dreigliedrig setzen, nie um ein viertes Wort erweitern. Reihenfolge ist fest: **Reaction** vor **Protection** vor **Solution**.

---

## 2. Logo-System

Die Bildmarke ist ein **"n" im Quadrat** (stilisiert, dickere Strichführung). Die Wortmarke "IgniTec" steht in **Poppins SemiBold** mit enger Laufweite (–2.5 Tracking). Poppins wird AUSSCHLIESSLICH in der Wortmarke verwendet — nicht für sonstige Typografie.

### Freigegebene Ausführungen

| Nr. | Variante | Bildmarke | Wortmarke | Einsatz |
|---|---|---|---|---|
| 4.2.1 | **Primary** | Kupferverlauf (#3A1612 → #80401D → #D06E3D) | Slateblue #152234 | Standardeinsatz auf hellem/Bone-Hintergrund |
| 4.2.2 | Mark 4c-Vollton | Ignis Copper #793907 | — (nur Zeichen) | App-Icon, Prägung, Kleingrößen |
| 4.2.3 | Mono weiß | Outline weiß | Bone #F5F2EC | 1c auf dunklem Hintergrund |
| 4.2.4 | Primary auf Slateblue | Kupferverlauf | Bone #F5F2EC | Dunkler Primäreinsatz |
| 4.2.5 | Reversed auf Copper | Slateblue #152234 | — | auf Kupferflächen/Keyvisuals |
| 4.2.6 | 1c Slateblue | Slateblue #152234 | Slateblue | Fax, Stempel, Einfarbdruck |

### Logo-Regeln

- **Schutzraum X** = Höhe der Bildmarke. Innerhalb keine Typografie, Grafik oder Bildkante.
- **Mindestgröße Vollmarke**: 22 mm Breite im Print, 88 px auf Screen
- **Mindestgröße nur Bildmarke**: 8 mm / 16 px
- Wortmarke nie im Kupferverlauf setzen — immer Slateblue oder Bone
- Keine 3D-Effekte im 2D-Kontext (Ausnahme: offizielles Keyvisual-Rendering)
- Wortmarke nie unter 16 px isoliert stehend (Verwechslungsgefahr mit Xiaomi "Mi")

---

## 3. Farbsystem

### Primärpalette

| Rolle | Name | CMYK | RGB | HEX | Pantone (nächstl.) |
|---|---|---|---|---|---|
| Verlauf hell | **Copper Light** | 15/55/75/4 | 208·110·61 | `#D06E3D` | 1595 C |
| Verlauf mitte | **Copper Mid** | 30/65/84/28 | 128·64·29 | `#80401D` | 7587 C |
| Verlauf dunkel | **Copper Deep** | 40/77/81/62 | 58·22·18 | `#3A1612` | 476 C |
| 4c Vollton Icon | **Ignis Copper** | 30/67/96/32 | 121·57·7 | `#793907` | 1615 C |
| Wortmarke/Träger | **Slateblue** | 78/64/45/63 | 21·34·52 | `#152234` | 5395 C |
| Paper/Ruhefläche | **Bone** | 2/3/6/0 | 245·242·236 | `#F5F2EC` | Offwhite |
| UI-Alarm/Accent | **Ember** | approx. 10/70/90/0 | 232·98·42 | `#E8622A` | 1655 C |

### Verlaufsspezifikation

**Linearer Kupferverlauf** (Hero, Bildmarke, Keyvisuals):

```css
background: linear-gradient(135deg, #3A1612 0%, #80401D 45%, #D06E3D 100%);
```

**Soft-Copper** (Text-Gradient für Akzentworte in Headlines):

```css
background: linear-gradient(180deg, #D06E3D 0%, #80401D 100%);
```

### Flächenverteilung (Regel)

- 60 % Slateblue/Ink (dunkle Träger) oder Bone (helle Träger)
- 25 % neutrale Grautöne
- 10 % Kupfer (Verlauf oder Vollton)
- 5 % Ember (ausschließlich UI-Alarme, Auslöse-States, niemals als Serienakzent)

### Einsatzregel

- Verlauf nur auf Bildmarke, Hero, Keyvisuals
- Wortmarke IMMER Slateblue (auf hell) oder Bone (auf dunkel) — nie im Verlauf
- 4c-Vollton ersetzt den Verlauf bei Stempel, Stickerei, Lasergravur, Fax, Kleinstdruck
- Bone ist warmer Off-White (#F5F2EC) — NICHT reines Weiß (#FFFFFF). Reines Weiß nur in extremen Druckfällen.

---

## 4. Typografie · Dual-Family-System

Zwei arbeitende Schriftfamilien + eine technische Stützschrift. Poppins bleibt ausschließlich der Wortmarke vorbehalten.

| Rolle | Schrift | Lizenz | Einsatz |
|---|---|---|---|
| **Logo-Wortmarke** | Poppins SemiBold (600) | OFL | AUSSCHLIESSLICH im Logo |
| **Display / Headlines** | **Archivo** (500–900) | OFL (Google Fonts) | H1–H3, Claims, Section-Titles, UI-Titel, Button-Labels |
| **Body / Fließtext** | **IBM Plex Sans** (300–500) | OFL (Google Fonts) | Body, UI-Formulare, Produktdetails, alles Gelesene |
| **Technisch / Werte** | **JetBrains Mono** (400–500) | Apache 2.0 | Artikelnummern, Messwerte, Eyebrows, Labels in UPPERCASE |

### Einsatz-Gewichte

**Archivo** (nur mittlere/schwere Gewichte):
- 500 Medium — Subheads, Stage-Titel
- 600 SemiBold — H1/H2 Standard
- 700 Bold — Buttons, Akzente
- 900 Black — Claim-Anker, Payoff-Wörter

**NICHT verwenden bei Archivo:** Thin 100, ExtraLight 200, Light 300, Regular 400 (zu filigran, schwächt die Autorität)

**IBM Plex Sans** (nur Light bis SemiBold):
- 300 Light — Body-Default, 16/17 px
- 400 Regular — Alternative für längere Texte
- 500 Medium — UI, Buttons, Emphasis
- 600 SemiBold — Inline-Betonung, Zitate

**NICHT verwenden bei Plex Sans:** ExtraLight 200, Bold 700 (würde mit Archivo-Territory kollidieren), Italic-Schnitte, Einsatz über 28 px (dort immer Archivo)

### Satz-Regeln

- **Tracking bei Headlines:** –3 % bis –5 % (Archivo verträgt sehr tightes Tracking)
- **Tracking bei Body:** 0 % bis –0.2 %
- **Versalsatz (UPPERCASE):** nur in JetBrains Mono 500 mit +14 % bis +26 % Letter-Spacing für Eyebrows/Labels
- **Keine Kursive.** Keine SmallCaps. Keine Variable-Axis-Spielereien.
- **Strong/Emphasis:** IBM Plex SemiBold 600 in Slateblue; im Body NIE Archivo mischen

### Typografie-Hierarchie (Referenz)

| Element | Font | Weight | Size (Desktop) | Line-Height | Tracking |
|---|---|---|---|---|---|
| Hero H1 | Archivo | 600 + 900 | 72–144 px (clamp) | 0.96 | –0.045em |
| Section H2 | Archivo | 500 + 900 | 38–78 px | 1.03 | –0.04em |
| H3 / Card Title | Archivo | 600 | 22–40 px | 1.05 | –0.02em |
| H4 / Subhead | Archivo | 500–600 | 18–24 px | 1.3 | –0.02em |
| Body Default | IBM Plex Sans | 300 | 16–17 px | 1.65 | 0 |
| Body Emphasis | IBM Plex Sans | 500–600 | 16–17 px | 1.65 | 0 |
| Caption | IBM Plex Sans | 300 | 13–14 px | 1.6 | 0 |
| Eyebrow/Label | JetBrains Mono | 500 | 11 px UPPERCASE | 1 | +0.26em |
| Tech-Data | JetBrains Mono | 400 | 13–14 px | 1.6 | 0.04em |

---

## 5. Stimme & Tonalität

Vier Prinzipien, gleichzeitig gültig:

| Prinzip | So | Nicht so |
|---|---|---|
| **Präzise** | "≤ 20 s Ausstoßzeit" | "superschnell" |
| **Ruhig** | "Der Generator reagiert." | "KATASTROPHE GESTOPPT!" |
| **Fallbezogen** | "Für 1,5 m³ Schaltschrank" | "Für jede Anwendung" |
| **Partnerschaftlich** | "Gemeinsam auslegen" | "Unsere Experten sagen Ihnen" |

Zahlen immer mit Einheiten ausschreiben. Kein "Revolution", kein "weltbester", keine Angstrhetorik. Feuer ist ernst genug — die Marke setzt Gegengewicht, nicht Lautstärke. Planer und Errichter sind Kolleg:innen, keine Kunden; die Sprache spiegelt das.

**Österreichisches Format:** "1.500 €" mit Punkt als Tausendertrenner, "1,5 m³" mit Komma als Dezimaltrenner, "°C" mit geschütztem Leerzeichen davor.

---

## 6. CSS-Design-Tokens (Web/HTML)

Zum direkten Kopieren in Stylesheets oder HTML-Artefakte:

```css
:root{
  /* Brand Colours */
  --copper-light:#D06E3D;
  --copper-mid:#80401D;
  --copper-deep:#3A1612;
  --copper-solid:#793907;
  --slateblue:#152234;
  --bone:#F5F2EC;
  --ember:#E8622A;

  /* Ink / Neutral System (dark UI) */
  --ink-000:#0B121C;
  --ink-100:#121A26;
  --ink-200:#1A2432;
  --ink-300:#22303F;
  --ink-400:#2C3A4B;
  --ink-500:#3D4A5C;

  /* Gradients */
  --gradient-copper:linear-gradient(135deg,#3A1612 0%,#80401D 45%,#D06E3D 100%);
  --gradient-copper-soft:linear-gradient(180deg,#D06E3D 0%,#80401D 100%);

  /* Typography Stacks */
  --ff-display:"Archivo","Helvetica Neue",Arial,sans-serif;
  --ff-body:"IBM Plex Sans","Helvetica Neue",Arial,sans-serif;
  --ff-mono:"JetBrains Mono",ui-monospace,monospace;
  --ff-logo:"Poppins","Helvetica Neue",Arial,sans-serif;
}
```

### Google-Fonts-Einbindung

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;900&family=IBM+Plex+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&family=Poppins:wght@600&display=swap" rel="stylesheet">
```

---

## 7. Logo als Inline-SVG (Web)

Primäre Variante (Verlauf + Slateblue-Wortmarke) zum direkten Einbinden:

```html
<svg viewBox="0 0 480 140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="IgniTec">
  <defs>
    <linearGradient id="ignitec-copper" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#3A1612"/>
      <stop offset="45%" stop-color="#80401D"/>
      <stop offset="100%" stop-color="#D06E3D"/>
    </linearGradient>
  </defs>
  <rect x="10" y="15" width="110" height="110" rx="3" fill="url(#ignitec-copper)"/>
  <path d="M40 105 V40 h20 c15 0 25 10 25 25 v40 h-15 v-38 c0 -8 -3 -12 -10 -12 h-5 v50 z" fill="#F5F2EC"/>
  <text x="145" y="96" font-family="Poppins, sans-serif" font-weight="600"
        font-size="72" fill="#152234" letter-spacing="-2.5">IgniTec</text>
</svg>
```

Für dunkle Hintergründe: `fill="#152234"` in `<text>` ändern zu `fill="#F5F2EC"`.

---

## 8. Produktdaten-Glossar (häufig benötigt)

Bei Datenblättern, Produktseiten, Angeboten.

| Feld | Format / Beispiel |
|---|---|
| Artikelnummer-Schema | `IGNI.ST{GROESSE}G.E/TH` (z. B. `IGNI.ST150G.E/TH`) |
| Produktkategorie | Aerosol-Feuerlöschgerät · Brandunterdrückungsanlage |
| Gerätegrößen (gängig) | 30 g · 60 g · 100 g · 150 g · 250 g · 500 g · 750 g · 1000 g · größer auf Anfrage |
| Löschkonzentration | 100 g/m³ (Standard) |
| Ausstoßzeit | ≤ 6 s (30 g) bis ≤ 40 s (≥ 250 g) |
| Lebensdauer | 15 Jahre |
| Betriebstemperatur | −50 °C bis +90 °C |
| Max. Umgebungsfeuchte | ≤ 95 % rLF |
| Brandklassen | A, B, C und elektrische Brände |
| Auslösung | Elektrisch (3–24 V DC / bis 220 V AC) · Thermisch (Glasampulle 68/93/140 °C, Thermoseil 175/300 °C) · Hybrid |
| Sicherheitsabstand Personen | 1,5 m |
| Sicherheitsabstand Objekte | 0,3 m |
| Material Gehäuse | Edelstahl SUS304 |
| Treibhauspotenzial | GWP = 0 |
| Ozonabbaupotenzial | ODP = 0 |
| Relevante Norm | CEN/TR 15276-1:2019 |
| Transport-UN | UN 3268 · Klasse 9 |

---

## 9. Website-Architektur (3-Stufen-Modell)

Bei Web-Aufgaben die Ausbaustufe mitdenken:

- **Stufe 0 · Basis-Website** (öffentlich, SEO): Home, Technologie, Produkte, Anwendungen, Referenzen, Wissen, Partner-Info, Über, Kontakt, Legal
- **Stufe A · Webshop** (öffentlich, Kleingeräte ≤ 150 g + Zubehör + NFC-Tags): Shop-Start, Kleingeräte, Zubehör, Konfigurator, Warenkorb, Checkout, Kundenkonto
- **Stufe B · Partner-Portal** (Login, 2FA): Dashboard, Konditionen/Rabatte, B2B-Bestellen, Projektkalkulation, Leads, Zertifizierung, Marketing-Kit, Tech-Support, Academy, Service, Vertragswerk

**Wichtig:** Direktverkauf im Shop NUR bis 150 g. Geräte ab 250 g sind auslegungspflichtig (Produkthaftung) — Flow geht über Konfigurator → Angebotsanfrage → Gebietspartner.

---

## 10. Do's & Don'ts

**Do:**
- Claim als festen Dreiklang setzen: "Reaction. Protection. Solution."
- Werte mit Einheiten und Toleranzen nennen
- Slateblue/Bone als Trägerflächen dominieren lassen, Kupfer punktuell
- Bei dunkler UI: Ink-Tokens (#0B121C / #121A26 …) nutzen, nicht reines Schwarz
- SUS304 · GWP 0 · ODP 0 als Kernargumente in Techkontext aktiv einsetzen

**Don't:**
- Keine Serifenschriften. Keine Italic-Setzungen in Body-Texten.
- Wortmarke nicht im Kupferverlauf
- Kein Poppins außerhalb des Logos
- Keine Emojis in Fachkommunikation (außer Social bei explizitem User-Wunsch)
- Nicht "TRVB-zugelassen" schreiben — relevante Norm ist CEN/TR 15276
- Aerosol nicht als "Gas-Ersatz" positionieren — es ist eine eigene Kategorie
- Keine Superlative ohne Quellenangabe

---

## 11. Output-Format je Task-Typ

| User-Request | Empfohlenes Format | Skill-Kombination |
|---|---|---|
| "Erstelle eine Website für IgniTec" | HTML-Artefakt (single file) | ignitec-brand + frontend-design |
| "Mach ein Datenblatt/Angebot" | .docx oder .pdf | ignitec-brand + docx/pdf |
| "Produktpräsentation" | .pptx | ignitec-brand + pptx |
| "Social-Post / LinkedIn" | Bild (SVG/PNG) oder Textentwurf | ignitec-brand standalone |
| "Fließtext, Blogartikel, Whitepaper" | .md oder .docx | ignitec-brand + docx |
| "E-Mail an Partner/Kunde" | Textentwurf inline | ignitec-brand + message_compose |

Immer prüfen: Wer ist Zielgruppe? Peter (Partner), Stefan (Planer) oder Elisabeth (Endkunde)? Die Tonalitätsfeinheit differiert: Peter = margenfokussiert, Stefan = normenfokussiert, Elisabeth = risikofokussiert.

---

## 12. Referenzen & Quelldokumente

- Vollständige Brand Strategy (HTML): frühere Ausgabe `IgniTec_Brand_Strategy_v3.html`
- Produkt-Datenblätter (PDF): IgniTec_PD_Aerosolgenerator_{30|60|100|150|250|500|750|1000}g.pdf
- Sicherheitsdatenblatt (PDF): IGNITEC_Sicherheitsdatenblatt_Rev_1.pdf
- Bedienungsanleitung (PDF): IGNI_BA_Aerosolgeneratoren_Rev_0.pdf
- Produkt-Etiketten: 260307_Etikette_IGNI_ST{0030|0100|0150|0500|0750|1000}.png

Bei Abweichungen immer zur Brand Strategy v3 rückkoppeln, nicht zu älteren Revisionen.
