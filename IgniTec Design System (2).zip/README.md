# Ignitec Design System

Design system and brand reference for **Ignitec GmbH** — Austrian sole distributor of condensed-aerosol fire-suppression generators. Lichtenwörth, AT. Brand Strategy Rev. 3.0, April 2026.

**Claim:** Reaction. Protection. Solution.
**Brand idea:** Wir verkaufen nicht Löschmittel — wir verkaufen die Minute, in der nichts passiert.
**Contact:** office@ignitec.at · www.ignitec.at · FN 651979v

---

## What this folder contains

| Path | What |
|---|---|
| `README.md` | This file — manifest, content & visual foundations, iconography |
| `SKILL.md` | Cross-compatible skill file for Claude Code / agents |
| `colors_and_type.css` | Full token set — brand colors, ink scale, type stacks, spacing, radii, shadows, motion, and semantic element styles |
| `fonts/` | Archivo variable font (roman + italic) — delivered by the brand; served locally via `@font-face` |
| `assets/` | Logos (PNG/PDF/WebP) and the copper/slate keyvisual |
| `preview/` | Small HTML cards that populate the Design System tab |
| `ui_kits/website/` | Pixel-level recreation of the ignitec.at marketing site (Header, Hero, StatBar, ProductGrid, ApplicationStrip, CTA, Footer) |
| `reference/ignitec-brand_SKILL_original.md` | Source brand document (German) — authoritative |

**Source of truth:** `reference/ignitec-brand_SKILL_original.md`. If something conflicts, that file wins.

---

## Products represented

Per Brand Strategy §9, the Ignitec web presence has **three build stages**. This design system currently covers **Stufe 0** (public marketing site). Stufe A (Webshop, devices ≤ 150 g) and Stufe B (Partner Portal, 2FA) are documented in `SKILL.md` but not yet mocked — ask and I'll add kits.

- **ui_kits/website/** — Stufe 0 marketing site

---

## CONTENT FUNDAMENTALS

### Language & locale
- **Primary language: German (DE-AT).** Austrian number format: `1.500 €` (dot = thousands), `1,5 m³` (comma = decimal), ` °C` with non-breaking space.
- All copy in this system is written in German. English only on request.

### Tone — four principles, always simultaneously
| Principle | So | Not so |
|---|---|---|
| **Präzise** (precise) | "≤ 20 s Ausstoßzeit" | "superschnell" |
| **Ruhig** (calm) | "Der Generator reagiert." | "KATASTROPHE GESTOPPT!" |
| **Fallbezogen** (case-specific) | "Für 1,5 m³ Schaltschrank" | "Für jede Anwendung" |
| **Partnerschaftlich** (collaborative) | "Gemeinsam auslegen" | "Unsere Experten sagen Ihnen" |

### Casing
- **Sentence case** everywhere in running text. No Title Case headlines.
- **UPPERCASE** only in JetBrains-Mono eyebrows/labels with +0.22–0.26em letter-spacing.
- The claim is set mixed-case or UPPERCASE, never Title Case.

### I / you / we
- **"Wir"** for the company (never "die Ignitec-Experten" or third-person).
- **"Sie"** for all B2B audiences (partners, planners, end customers). No "du".
- **"Gemeinsam"** is the keyword — planners and installers are *Kolleg:innen*, not customers.

### Numbers & values
- **Always with units.** `≤ 20 s`, never "20 seconds" or "superfast".
- Tolerances explicit: `−50 °C bis +90 °C`, `≤ 95 % rLF`.
- No superlatives without a source. No "revolution", no "world's best".
- Fire risk is real — the brand plays *counterweight*, not volume.

### Emoji
- **No emoji in technical communication.** Only on Social, and only when the user explicitly asks.
- The one exception: ⚠ may appear as an alarm icon in an Ember alert banner (see `components-alert.html`).

### The three-part claim
- **Always triadic: "Reaction. Protection. Solution."** Never add a fourth word. Order is fixed.
- Set in JetBrains Mono 500, uppercase, +0.22em, copper.

### Do / don't (excerpt)
- ✗ No Serif typefaces. No italics in body.
- ✗ Never "TRVB-zugelassen" — the correct norm is **CEN/TR 15276-1**.
- ✗ Do not position Aerosol as "Gas-Ersatz" — it is a category of its own.
- ✓ Always lead with `SUS304 · GWP 0 · ODP 0` in technical contexts.

### Audience tuning (per brand doc §11)
Three B2B personas — detect which and adjust emphasis:
- **Peter (Partner)** — margin-focused. Lead with conditions, rebates, lead quality.
- **Stefan (Planner)** — norm-focused. Lead with CEN/TR 15276, data sheets, test data.
- **Elisabeth (End customer)** — risk-focused. Lead with "die Minute, in der nichts passiert", case studies, uptime.

---

## VISUAL FOUNDATIONS

### Colors
- **Primary carriers (60%):** Slateblue `#152234` (dark) OR Bone `#F5F2EC` (light). Bone is a *warm* off-white — **never** pure `#FFFFFF` except in extreme print cases.
- **Neutrals (25%):** Bone-scale on light, Ink-000…500 on dark. Never pure black.
- **Copper accent (10%):** The 4-stop ramp `#3A1612 → #80401D → #D06E3D`, or the 4c solid `#793907` (Ignis Copper) when gradient isn't possible (stamp, embroidery, laser, fax, tiny print).
- **Ember (5% max):** `#E8622A` — alarm and trigger-state UI only. Never a serial accent color.
- **Gradient rule:** copper gradient appears on the logo mark, hero keyvisuals, and section-level carriers — **never** on the wordmark, never on body text.

### Typography
Dual-family system (plus one reserved for the logo):
- **Display · Archivo** — 500/600/700/900 only. Never Thin/Light/Regular — they weaken authority.
- **Body · IBM Plex Sans** — 300/400/500/600. No Bold 700, no italic cuts.
- **Tech · JetBrains Mono** — 400/500. Eyebrows, SKUs, tech data, the claim.
- **Logo only · Poppins SemiBold** — never used elsewhere.
- Headline tracking: −3% to −5%. Body tracking: 0 to −0.2%. Eyebrows: +22–26%.
- No italic. No small-caps. No variable-axis experimentation.
- **Hero Claim Exception.** One payoff word per hero claim may break the no-italic / no-text-gradient rules — and ONLY that word, ONLY in that context. Rules for the exception:
  - Hero claim must sit on a **dark carrier** — Slateblue `#152234` or Ink `#0B121C` — with a subtle fiery radial glow (Ember/Copper at 18–30% alpha, see `preview/brand-keyvisual.html` for the canonical recipe).
  - Headline is Archivo 500–600, uniform weight across all lines. The payoff word sits on its **own line**, **same weight** as the rest.
  - Payoff word is **Archivo Italic** with the copper gradient as text-fill (`background:linear-gradient(92deg,#B7591E 0%,#E89A5C 55%,#F0B074 100%); -webkit-background-clip:text; color:transparent`).
  - **Exactly one payoff word per claim.** Never a phrase, never two words, never on light backgrounds, never anywhere outside the hero carrier.

### Spacing
8-point grid — tokens `--s-1` (4px) through `--s-10` (128px). Section padding is usually `s-9` (96px) desktop, `s-6` (32px) mobile.

### Backgrounds
- **Primary canvas is flat Bone or flat Slateblue.** No texture, no grain, no noise overlays in running UI.
- Hero carriers: the copper gradient at 135° — used once per screen, as the dominant visual moment.
- No hand-drawn illustrations. No pattern fills. No repeating textures.
- Full-bleed photography is allowed for keyvisuals (matte/slate aesthetic — see `assets/keyvisual-copper-slate.png`): warm metallic copper on cool stone or slateblue backgrounds. Never warm-cozy product lifestyle, never stock "firefighter in action" drama.
- Imagery is **cool + metallic + quiet** — not warm, not saturated, not heroic.

### Gradients
Only two are approved:
- `--gradient-copper` — 135° `#3A1612 → 45% #80401D → #D06E3D`. Hero, mark, keyvisual.
- `--gradient-copper-soft` — 180° `#D06E3D → #80401D`. Text-gradient on accent words in headlines only.
- No bluish-purple gradients. No rainbow. No mesh.

### Motion
- **Calm.** `--dur-base` 220ms, `cubic-bezier(.2,.6,.2,1)` standard easing.
- Fades and 4–8 px slide-ins for entry. No bounce, no spring overshoot, no elastic.
- Hover: `color` shifts to `--accent-hover` (`#6A3206`) or opacity to 0.85.
- Press: color shift to `--accent-press` (`#5A2A05`) — no scale-down, no shrink.
- Focus: 3 px `rgba(121,57,7,0.30)` ring. Always visible, never suppressed.

### Borders & hairlines
- Light UI: `1px solid rgba(21,34,52,0.10)` for most dividers, `rgba(21,34,52,0.16)` for inputs.
- Dark UI: `1px solid rgba(245,242,236,0.10)`.
- Never use a colored accent border to decorate a card. (No left-border accent stripe tropes.)

### Inner / outer shadow
- Four elevation tokens (`--shadow-1` through `--shadow-4`), all tinted with slateblue — shadows are neutral, not copper.
- `--shadow-ember` — 3px ring around alarm-state elements.
- `--shadow-focus` — 3px copper ring on keyboard focus.
- No inner-shadow decoration. No glow effects (except the focused/armed ring).

### Protection gradients vs capsules
- On copper or photo carriers, place text directly on the surface with enough weight (Archivo 600+) to cut through. If that fails, use a **solid Slateblue or Bone capsule** behind the text — never a translucent gradient wash.
- Capsules are flat rectangles, radius `--r-2` (4 px).

### Layout rules
- Max content width: **1280 px**. 28 px side padding desktop, 20 px tablet, 16 px mobile.
- Grid: 12 columns desktop, gutters 24 px.
- Sticky: the header only. No sticky CTAs, no floating "jetzt anfragen" button — it would break the ruhig principle.

### Transparency & blur
- Used sparingly: only on the sticky header (`rgba(245,242,236,0.92)` + `backdrop-filter: saturate(1.2) blur(10px)`) to let content scroll under without cluttering.
- Never on cards, never on modals, never as a background pattern.

### Imagery color vibe
- **Cool + metallic.** Slateblue stone, brushed copper, matte steel, warm-backlit cracks.
- NOT warm sunset, NOT saturated RGB, NOT grain-heavy, NOT black-and-white.
- If photography is not available, use the solid copper gradient as the visual moment — better than stock imagery.

### Corner radii
Restrained. Tokens:
- `--r-0` 0 (hairline dividers, data tables)
- `--r-1` 2 (chips, tiny buttons)
- `--r-2` 4 (inputs, logo mark, data capsules)
- `--r-3` 6 (standard buttons)
- `--r-4` 10 (cards)
- `--r-5` 14 (large panels, hero block)
- `--r-pill` 999 (status chips only)

No giant (20 px+) radii. No squircles. No asymmetric corners.

### Cards
- Background `#FBF9F4` (subtle lift from Bone) on a Bone page, or ink-100 on dark.
- Radius `--r-4` (10 px).
- Border 1 px `rgba(21,34,52,0.06)` OR `--shadow-2` — pick one, never both.
- No colored left-border stripes. No gradient fills. No emoji.

---

## ICONOGRAPHY

Ignitec does **not** ship a proprietary icon font. The brand is restrained — when in doubt, use **no icon**.

### Approach
- **Minimal, stroked, geometric.** When icons appear, they are line-style, 1.5–2 px stroke, square-cornered, matching Archivo's geometry.
- **Substitute: Lucide** (`https://unpkg.com/lucide-static/icons/`) — stroke 1.75, square caps, good geometric match to the wordmark. Use via CDN SVG include or the Lucide React/vanilla library.
- ⚠ **Flag:** no Ignitec-native icon set exists in the provided materials. If you ship production UI with Lucide, note the substitution in implementation.

### When NOT to use icons
- Never in headlines.
- Never as bullet replacements next to list items in body copy.
- Never decoratively next to buttons (the button label is enough).
- Never as emoji.

### Logos and marks
Copied into `assets/`:
- `logo-mark-copper.png` / `.pdf` — gradient "n-square" mark, approved variant 4.2.1
- `logo-full-copper.pdf` — mark + wordmark
- `logo-full-white.webp` — 1c white on dark (variant 4.2.3)
- `keyvisual-copper-slate.png` — 3D embossed hero keyvisual on slate stone
- An **inline-SVG primary logo** lives in `colors_and_type.css` comments and in the UI kit `Header.jsx` — preferred over raster for UI.

### Unicode / emoji
- **Never** in technical or formal communication.
- Social posts may use unicode glyphs (✕, →, ·) sparingly. The middle-dot `·` is the brand's preferred separator (e.g. `REACTION · PROTECTION · SOLUTION`).

---

## Next steps / asks

See the bold ask at the end of this message in chat. In short: the logo SVG approximation needs replacing with the real vector, the Stufe A (Shop) and Stufe B (Partner Portal) UI kits aren't built yet, and Lucide is a substitution, not an official pick.
