---
name: ignitec-design
description: Use this skill to generate well-branded interfaces and assets for Ignitec (Ignitec GmbH, Lichtenwörth AT — condensed-aerosol fire-suppression generators), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. Trigger on: "Ignitec", "Ignitec", "Aerosol-Generator", "Brandunterdrückung", "Reaction. Protection. Solution.", copper/slateblue colors, or Archivo/IBM Plex Sans typography. Do NOT use for other fire-suppression companies.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files. Key files:

- `README.md` — brand context, content fundamentals, visual foundations, iconography
- `colors_and_type.css` — all tokens ready to import
- `reference/ignitec-brand_SKILL_original.md` — source brand document (German, authoritative)
- `assets/` — logos and keyvisual
- `ui_kits/website/` — pixel-level recreation of ignitec.at components (Header, Hero, StatBar, ProductGrid, ApplicationStrip, CTA, Footer)
- `preview/` — small HTML specimens per token group

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. Import `colors_and_type.css` and reuse the inline components in `ui_kits/website/` rather than hand-writing styles. If working on production code, copy assets and read the rules here to become an expert in designing with this brand.

Hard rules (non-negotiable):
- Claim is always "Reaction. Protection. Solution." — three words, fixed order, never a fourth.
- Wordmark is Poppins SemiBold, used ONLY in the logo — never for headlines or body.
- Bone `#F5F2EC` is the light canvas, NOT pure white.
- Copper gradient never touches the wordmark. Text on copper is Slateblue or Bone.
- No italic. No emoji in technical contexts. No serifs. No "TRVB" — the norm is CEN/TR 15276-1.
- German (DE-AT) is the default language. Austrian number format.

**Hero Claim — single controlled exception to the no-italic / no-text-gradient rules.**
Exactly one payoff word per hero claim may be set in Archivo Italic with the copper gradient as text-fill. Conditions (all must hold):
- Dark carrier only — Slateblue `#152234` or Ink `#0B121C` — with a subtle fiery radial glow (Ember/Copper 18–30% alpha).
- Headline is Archivo 500–600 at uniform weight across all lines; the payoff word sits on its own line at the same weight as the rest.
- Fill: `background:linear-gradient(92deg,#B7591E 0%,#E89A5C 55%,#F0B074 100%); -webkit-background-clip:text; color:transparent; font-style:italic;`
- One word. Not a phrase. Not two words. Not on light backgrounds. Never outside a hero carrier. Canonical recipe: `preview/brand-keyvisual.html`.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions (target audience: Partner/Planer/Endkunde? Stufe 0/A/B? language?), and act as an expert designer who outputs HTML artifacts or production code, depending on the need.
