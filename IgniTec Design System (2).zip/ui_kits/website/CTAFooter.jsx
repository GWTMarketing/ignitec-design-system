/** @jsx React.createElement */
/* CTAStrip.jsx + Footer.jsx — final CTA band + footer */
const CTAStrip = () => (
  <section style={{
    background: "linear-gradient(135deg,#3A1612 0%,#80401D 45%,#D06E3D 100%)",
    padding: "88px 28px", color: "#F5F2EC",
  }}>
    <div style={{
      maxWidth: 1280, margin: "0 auto",
      display: "grid", gridTemplateColumns: "1.4fr auto", gap: 48, alignItems: "center",
    }}>
      <div>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace', fontWeight: 500, fontSize: 11,
          letterSpacing: "0.26em", textTransform: "uppercase", color: "#F5F2EC", opacity: 0.85,
        }}>PARTNER · PLANER · ENDKUNDE</div>
        <h2 style={{
          fontFamily: 'Archivo, sans-serif', fontWeight: 600, fontSize: 56,
          lineHeight: 0.98, letterSpacing: "-0.045em", color: "#F5F2EC", margin: "12px 0 14px",
        }}>
          Gemeinsam auslegen.<br/>
          <span style={{ fontWeight: 900 }}>Ruhig entscheiden.</span>
        </h2>
        <p style={{
          fontFamily: 'IBM Plex Sans, sans-serif', fontWeight: 300, fontSize: 17,
          color: "rgba(245,242,236,0.9)", maxWidth: "52ch",
        }}>
          Wir legen das Schutzkonzept gemeinsam mit Ihnen aus — normenkonform nach CEN/TR 15276-1, im Regelfall innerhalb von 48 h.
        </p>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        <button style={{
          fontFamily: 'Archivo, sans-serif', fontWeight: 700, fontSize: 15,
          color: "#152234", background: "#F5F2EC", border: 0,
          borderRadius: 6, padding: "16px 28px", cursor: "pointer", minWidth: 240,
        }}>Konfigurator starten →</button>
        <button style={{
          fontFamily: 'Archivo, sans-serif', fontWeight: 700, fontSize: 15,
          color: "#F5F2EC", background: "transparent",
          border: "1.5px solid #F5F2EC",
          borderRadius: 6, padding: "15px 27px", cursor: "pointer",
        }}>Partner werden</button>
      </div>
    </div>
  </section>
);

const Footer = () => (
  <footer style={{ background: "#0B121C", color: "#B8BFC9", padding: "56px 28px 28px" }}>
    <div style={{ maxWidth: 1280, margin: "0 auto" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1fr 1fr", gap: 32 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
            <svg viewBox="0 0 140 140" width="28" height="28">
              <rect x="10" y="10" width="120" height="120" rx="4" fill="none" stroke="#F5F2EC" strokeWidth="3"/>
              <path d="M42 118 V42 h24 c18 0 30 12 30 30 v46 h-18 v-44 c0 -9 -4 -14 -12 -14 h-7 v58 z" fill="#F5F2EC"/>
            </svg>
            <span style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600, fontSize: 20, letterSpacing: "-0.035em", color: "#F5F2EC" }}>Ignitec</span>
          </div>
          <div style={{ fontFamily: 'IBM Plex Sans, sans-serif', fontSize: 13, lineHeight: 1.6, color: "#7F8897" }}>
            Ignitec GmbH<br/>
            Michael-Hainisch-Straße 8<br/>
            A-2493 Lichtenwörth<br/>
            FN 651979v · ATU81975427
          </div>
        </div>
        {[
          { h: "Produkt", items: ["Serie ST", "Zubehör", "Konfigurator", "Datenblätter"] },
          { h: "Anwendung", items: ["Schaltschrank", "BESS", "Maschinenraum", "Serverraum"] },
          { h: "Unternehmen", items: ["Über", "Referenzen", "Presse", "Karriere"] },
          { h: "Service", items: ["Kontakt", "Partner-Portal", "Downloads", "Legal"] },
        ].map(c => (
          <div key={c.h}>
            <div style={{
              fontFamily: 'JetBrains Mono, monospace', fontWeight: 500, fontSize: 10,
              letterSpacing: "0.26em", textTransform: "uppercase", color: "#D06E3D", marginBottom: 12,
            }}>{c.h}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {c.items.map(i => (
                <a key={i} href="#" style={{
                  fontFamily: 'IBM Plex Sans, sans-serif', fontWeight: 300, fontSize: 14,
                  color: "#B8BFC9", textDecoration: "none",
                }}>{i}</a>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div style={{
        marginTop: 44, paddingTop: 20, borderTop: "1px solid rgba(245,242,236,0.08)",
        display: "flex", justifyContent: "space-between", alignItems: "center",
      }}>
        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "#D06E3D" }}>
          REACTION · PROTECTION · SOLUTION
        </div>
        <div style={{ fontFamily: 'IBM Plex Sans, sans-serif', fontSize: 12, color: "#7F8897" }}>
          © 2026 Ignitec GmbH · office@ignitec.at
        </div>
      </div>
    </div>
  </footer>
);

window.CTAStrip = CTAStrip;
window.Footer = Footer;
