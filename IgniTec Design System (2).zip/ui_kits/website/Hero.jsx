/** @jsx React.createElement */
/* Hero.jsx — dark carrier with animated spark canvas + editorial claim */
const Hero = () => {
  const canvasRef = React.useRef(null);

  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let W, H, raf;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const resize = () => {
      W = canvas.width = canvas.offsetWidth;
      H = canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const COLORS = [
      'rgba(200,105,30,',
      'rgba(255,107,28,',
      'rgba(244,169,98,',
    ];
    const COUNT = reduced ? 25 : 140;
    const particles = [];
    const makeParticle = (init) => ({
      x: Math.random() * W,
      y: init ? Math.random() * H : H + Math.random() * 60,
      vy: -(0.35 + Math.random() * 0.9),
      vx: (Math.random() - 0.5) * 0.4,
      r: 0.6 + Math.random() * 1.8,
      life: 0,
      maxLife: 180 + Math.random() * 240,
      tw: Math.random() * 10,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
    });
    for (let i = 0; i < COUNT; i++) particles.push(makeParticle(true));

    const tick = () => {
      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = 'lighter';
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.life++;
        p.tw += 0.05;
        p.x += p.vx + Math.sin(p.tw) * 0.25;
        p.y += p.vy;
        p.vy -= 0.003;
        const t = p.life / p.maxLife;
        const alpha = Math.max(0, 1 - t) * (0.5 + 0.5 * Math.sin(p.tw));
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.color + alpha + ')';
        ctx.shadowColor = p.color + '0.9)';
        ctx.shadowBlur = 14;
        ctx.fill();
        if (p.life > p.maxLife || p.y < -10) {
          Object.assign(particles[i], makeParticle(false));
        }
      }
      ctx.globalCompositeOperation = 'source-over';
      ctx.shadowBlur = 0;
      if (!reduced) raf = requestAnimationFrame(tick);
    };
    tick();
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, []);

  return (
    <section style={{
      position: "relative",
      minHeight: "100vh",
      background: "#0A0B0D",
      overflow: "hidden",
      isolation: "isolate",
    }}>
      {/* Spark canvas (full-bleed) */}
      <canvas ref={canvasRef} style={{
        position: "absolute", inset: 0, width: "100%", height: "100%", zIndex: 0,
      }}/>

      {/* Heat-glow at bottom */}
      <div aria-hidden="true" style={{
        position: "absolute", left: 0, right: 0, bottom: -200, height: 500,
        background: "radial-gradient(ellipse at center, rgba(200,105,30,.28) 0%, rgba(200,105,30,0) 60%)",
        filter: "blur(30px)", pointerEvents: "none", zIndex: 1,
      }}/>

      {/* Right-half slot — user will drop a PNG here */}
      <div aria-hidden="true" data-slot="right-keyvisual" style={{
        position: "absolute", right: 0, top: 0, bottom: 0, width: "45%",
        zIndex: 2, pointerEvents: "none",
        // background-image: url(...);  ← user adds PNG
      }}/>

      {/* Content */}
      <div style={{
        position: "relative", zIndex: 3,
        maxWidth: 1280, margin: "0 auto",
        padding: "180px 28px 96px",
        display: "grid", gridTemplateColumns: "1.25fr 1fr", gap: 56, alignItems: "center",
      }}>
        <div>
          <div style={{
            fontFamily: 'JetBrains Mono, monospace', fontWeight: 500, fontSize: 11,
            letterSpacing: "0.26em", textTransform: "uppercase", color: "#E8622A",
            marginBottom: 20, display: "flex", alignItems: "center", gap: 14,
          }}>
            <span style={{ width: 34, height: 1, background: "#E8622A" }}/>
            REACTION · PROTECTION · SOLUTION
          </div>
          <h1 style={{
            fontFamily: 'Archivo, sans-serif', fontWeight: 500, fontSize: 84,
            lineHeight: 1.02, letterSpacing: "-0.035em", color: "#F5F2EC", margin: 0,
          }}>
            Wenn ein Funke<br/>
            über Millionen<br/>
            <span style={{
              fontFamily: 'Archivo, sans-serif', fontWeight: 500, fontStyle: "italic",
              background: "linear-gradient(92deg,#B7591E 0%,#E89A5C 55%,#F0B074 100%)",
              WebkitBackgroundClip: "text", backgroundClip: "text",
              WebkitTextFillColor: "transparent", color: "transparent",
            }}>entscheidet.</span>
          </h1>
          <p style={{
            fontFamily: 'IBM Plex Sans, sans-serif', fontWeight: 300, fontSize: 19,
            lineHeight: 1.55, color: "rgba(245,242,236,0.82)", maxWidth: "54ch", marginTop: 28,
          }}>
            Kondensierte Aerosol-Löschgeneratoren für Schaltschrank, BESS und Objektschutz. Reagiert in ≤ 20 s, rückstandsarm, GWP 0.
          </p>
          <div style={{ display: "flex", gap: 12, marginTop: 32 }}>
            <button style={{
              fontFamily: 'Archivo, sans-serif', fontWeight: 700, fontSize: 15,
              color: "#F5F2EC",
              background: "linear-gradient(135deg,#6B3410 0%,#C8691E 40%,#F4A962 75%,#FFD8A6 100%)",
              border: 0, borderRadius: 6, padding: "14px 22px", cursor: "pointer",
            }}>Konfigurator starten</button>
            <button style={{
              fontFamily: 'Archivo, sans-serif', fontWeight: 700, fontSize: 15,
              color: "#F5F2EC", background: "transparent",
              border: "1.5px solid rgba(245,242,236,0.65)",
              borderRadius: 6, padding: "13px 21px", cursor: "pointer",
            }}>Datenblätter ansehen</button>
          </div>
        </div>
        {/* right column intentionally empty — PNG will carry the visual */}
        <div/>
      </div>
    </section>
  );
};
window.Hero = Hero;
