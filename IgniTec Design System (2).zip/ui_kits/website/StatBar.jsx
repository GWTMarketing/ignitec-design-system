/** @jsx React.createElement */
/* StatBar.jsx — hard numbers row */
const StatBar = () => {
  const stats = [
    { k: "≤ 20 s", v: "Ausstoßzeit" },
    { k: "−50 … +90 °C", v: "Betriebstemperatur" },
    { k: "15", v: "Jahre Lebensdauer" },
    { k: "0 / 0", v: "GWP · ODP" },
    { k: "SUS304", v: "Edelstahl-Gehäuse" },
  ];
  return (
    <section style={{ background: "#152234", padding: "44px 28px" }}>
      <div style={{
        maxWidth: 1280, margin: "0 auto",
        display: "grid", gridTemplateColumns: `repeat(${stats.length},1fr)`, gap: 24,
      }}>
        {stats.map((s, i) => (
          <div key={i} style={{ borderLeft: i === 0 ? "none" : "1px solid rgba(245,242,236,0.12)", paddingLeft: i === 0 ? 0 : 24 }}>
            <div style={{
              fontFamily: 'Archivo, sans-serif', fontWeight: 600, fontSize: 32,
              lineHeight: 1, letterSpacing: "-0.03em", color: "#F5F2EC",
            }}>{s.k}</div>
            <div style={{
              fontFamily: 'JetBrains Mono, monospace', fontWeight: 500, fontSize: 10,
              letterSpacing: "0.22em", textTransform: "uppercase",
              color: "#D06E3D", marginTop: 8,
            }}>{s.v}</div>
          </div>
        ))}
      </div>
    </section>
  );
};
window.StatBar = StatBar;
