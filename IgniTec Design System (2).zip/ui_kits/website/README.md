# Website UI Kit · ignitec.at (Stufe 0)

Marketing-site components for the public Ignitec website. High-fidelity, light on functionality.

## Components
- `Header.jsx` — sticky bone-transparent nav with inline SVG logo mark
- `Hero.jsx` — copper keyvisual + "Die Minute, in der nichts passiert" claim
- `StatBar.jsx` — dark slateblue band of hard numbers (≤ 20 s, GWP 0, SUS304 …)
- `ProductGrid.jsx` — 6 Serie-ST product cards with SKU + auslegungspflichtig flag
- `ApplicationStrip.jsx` — 4 use-case tiles (Schaltschrank, BESS, …)
- `CTAFooter.jsx` — copper CTA band + ink-000 footer
