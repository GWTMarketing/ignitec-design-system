/** @jsx React.createElement */
/* ProductGrid.jsx — aerosol generator size cards */
const ProductGrid = () => {
  const products = [
    { sku: "IGNI.ST030G.E/TH", size: "30 g", volume: "0,3 m³", time: "≤ 6 s" },
    { sku: "IGNI.ST060G.E/TH", size: "60 g", volume: "0,6 m³", time: "≤ 10 s" },
    { sku: "IGNI.ST100G.E/TH", size: "100 g", volume: "1,0 m³", time: "≤ 15 s" },
    { sku: "IGNI.ST150G.E/TH", size: "150 g", volume: "1,5 m³", time: "≤ 20 s" },
    { sku: "IGNI.ST250G.E/TH", size: "250 g", volume: "2,5 m³", time: "≤ 25 s", auslegung: true },
    { sku: "IGNI.ST500G.E/TH", size: "500 g", volume: "5,0 m³", time: "≤ 32 s", auslegung: true },
  ];
  return (
    <section style={{ background: "#F5F2EC", padding: "88px 28px" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace', fontWeight: 500, fontSize: 11,
          letterSpacing: "0.26em", textTransform: "uppercase", color: "#793907",
        }}>PRODUKTE · SERIE ST</div>
        <h2 style={{
          fontFamily: 'Archivo, sans-serif', fontWeight: 500, fontSize: 52,
          lineHeight: 1.03, letterSpacing: "-0.04em", color: "#152234", margin: "10px 0 8px",
        }}>
          Sechs Gerätegrößen.<br/>
          <span style={{ fontWeight: 900 }}>Ein Auslegungsprinzip.</span>
        </h2>
        <p style={{
          fontFamily: 'IBM Plex Sans, sans-serif', fontWeight: 300, fontSize: 17,
          color: "#3A4656", maxWidth: "60ch", marginBottom: 36,
        }}>
          Löschkonzentration 100 g/m³ — Gerätewahl folgt dem geschützten Volumen.
          Geräte ab 250 g sind auslegungspflichtig.
        </p>
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16,
        }}>
          {products.map(p => (
            <div key={p.sku} style={{
              background: "#FBF9F4", borderRadius: 10, padding: 22,
              boxShadow: "0 2px 6px rgba(21,34,52,0.08), 0 1px 2px rgba(21,34,52,0.05)",
              display: "grid", gridTemplateColumns: "72px 1fr", gap: 18, alignItems: "center",
            }}>
              <div style={{
                width: 72, height: 72,
                background: "linear-gradient(135deg,#3A1612 0%,#80401D 45%,#D06E3D 100%)",
                borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <svg viewBox="0 0 140 140" width={30}>
                  <path d="M42 118 V42 h24 c18 0 30 12 30 30 v46 h-18 v-44 c0 -9 -4 -14 -12 -14 h-7 v58 z" fill="#F5F2EC"/>
                </svg>
              </div>
              <div style={{ minWidth: 0 }}>
                <div style={{
                  fontFamily: 'JetBrains Mono, monospace', fontWeight: 500, fontSize: 10,
                  letterSpacing: "0.18em", color: "#793907",
                }}>{p.sku}</div>
                <div style={{
                  fontFamily: 'Archivo, sans-serif', fontWeight: 600, fontSize: 22,
                  letterSpacing: "-0.02em", color: "#152234", marginTop: 2,
                }}>Aerosolgenerator · {p.size}</div>
                <div style={{
                  fontFamily: 'IBM Plex Sans, sans-serif', fontWeight: 300, fontSize: 13,
                  color: "#3A4656", marginTop: 4,
                }}>Für {p.volume} · {p.time}</div>
                {p.auslegung && (
                  <div style={{
                    display: "inline-block", marginTop: 8,
                    fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: "0.12em",
                    color: "#793907", background: "#ECE6DA", padding: "3px 8px", borderRadius: 999,
                  }}>AUSLEGUNGSPFLICHTIG</div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
window.ProductGrid = ProductGrid;
