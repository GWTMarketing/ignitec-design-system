/** @jsx React.createElement */
/* ApplicationStrip.jsx — use-case tiles */
const ApplicationStrip = () => {
  const apps = [
    { t: "Schaltschrank", d: "0,3 – 2,5 m³ · thermisch oder elektrisch ausgelöst" },
    { t: "BESS / Battery Rack", d: "Thermal Runaway früh unterdrücken" },
    { t: "Maschinenraum", d: "CNC, Hydraulik, Blockheizkraftwerk" },
    { t: "Serverraum", d: "Rückstandsarm, keine Ausgasung" },
  ];
  return (
    <section style={{ background: "#ECE6DA", padding: "72px 28px" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace', fontWeight: 500, fontSize: 11,
          letterSpacing: "0.26em", textTransform: "uppercase", color: "#793907",
        }}>ANWENDUNGEN</div>
        <h2 style={{
          fontFamily: 'Archivo, sans-serif', fontWeight: 500, fontSize: 40,
          lineHeight: 1.03, letterSpacing: "-0.04em", color: "#152234", margin: "10px 0 32px",
        }}>Wo Aerosol die richtige Antwort ist.</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14 }}>
          {apps.map((a, i) => (
            <div key={i} style={{
              background: "#F5F2EC", borderRadius: 10, padding: 22, minHeight: 160,
              display: "flex", flexDirection: "column", justifyContent: "space-between",
              border: "1px solid rgba(21,34,52,0.06)",
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 4,
                background: "linear-gradient(135deg,#3A1612 0%,#80401D 45%,#D06E3D 100%)",
              }}/>
              <div>
                <div style={{
                  fontFamily: 'Archivo, sans-serif', fontWeight: 600, fontSize: 19,
                  letterSpacing: "-0.02em", color: "#152234",
                }}>{a.t}</div>
                <div style={{
                  fontFamily: 'IBM Plex Sans, sans-serif', fontWeight: 300, fontSize: 13,
                  lineHeight: 1.55, color: "#3A4656", marginTop: 6,
                }}>{a.d}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
window.ApplicationStrip = ApplicationStrip;
