/** @jsx React.createElement */
/* Header.jsx — top navigation bar, dark carrier over hero */
const Header = ({ active = "Home" }) => {
  const links = ["Technologie", "Produkte", "Anwendungen", "Referenzen", "Wissen", "Über", "Kontakt"];
  return (
    <header style={{
      position: "absolute", top: 0, left: 0, right: 0, zIndex: 10,
      padding: "18px 28px",
      background: "linear-gradient(180deg, rgba(10,11,13,.92) 0%, rgba(10,11,13,.6) 70%, transparent 100%)",
      backdropFilter: "blur(10px)",
      WebkitBackdropFilter: "blur(10px)",
      borderBottom: "1px solid rgba(200,105,30,.08)",
    }}>
      <div style={{
        maxWidth: 1280, margin: "0 auto",
        display: "flex", alignItems: "center", gap: 32,
      }}>
        <a href="#" style={{ display: "flex", alignItems: "center", gap: 10, textDecoration: "none" }}>
          <img src="../../assets/logo-full-white.png" alt="Ignitec" style={{ height: 26, width: "auto", display: "block" }}/>
        </a>
        <nav style={{ display: "flex", gap: 22, flex: 1 }}>
          {links.map(l => (
            <a key={l} href="#" style={{
              fontFamily: 'IBM Plex Sans, sans-serif', fontWeight: 500,
              fontSize: 14, color: active === l ? "#F4A962" : "rgba(245,242,236,0.82)",
              textDecoration: "none", padding: "6px 2px",
              borderBottom: active === l ? "2px solid #C8691E" : "2px solid transparent",
            }}>{l}</a>
          ))}
        </nav>
        <span style={{
          fontFamily: 'JetBrains Mono, monospace', fontSize: 11,
          letterSpacing: "0.2em", textTransform: "uppercase", color: "rgba(245,242,236,0.55)",
        }}>DE · AT</span>
        <button style={{
          fontFamily: 'Archivo, sans-serif', fontWeight: 700, fontSize: 13,
          color: "#F5F2EC",
          background: "linear-gradient(135deg,#6B3410 0%,#C8691E 40%,#F4A962 75%,#FFD8A6 100%)",
          border: 0, borderRadius: 6, padding: "10px 18px", cursor: "pointer",
        }}>Angebot anfordern</button>
      </div>
    </header>
  );
};
window.Header = Header;
